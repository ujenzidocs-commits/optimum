# 🚀 Dynamic Website Upgrade — Implementation Guide

## What's Changed

| File | Change |
|---|---|
| `src/components/Navbar.tsx` | New logo (embedded), scroll effect, animated links, phone CTA |
| `src/components/Footer.tsx` | New logo (inverted white), animated social links, back-to-top |
| `src/components/Hero.tsx` | Fully animated hero with floating cards, parallax scroll, dynamic content from Firebase |
| `src/components/AnnouncementBanner.tsx` | **NEW** — Firebase-driven dismissable site-wide banner |
| `src/lib/useSiteContent.ts` | **NEW** — Firebase real-time content hook (edit site without redeploying) |
| `src/App.tsx` | Wires in AnnouncementBanner + new components |

---

## Step 1 — Copy the files

Copy each file from this folder into your repo, keeping the same paths:

```
src/
  App.tsx                          ← replace existing
  components/
    Navbar.tsx                     ← replace existing
    Footer.tsx                     ← replace existing
    Hero.tsx                       ← replace existing
    AnnouncementBanner.tsx         ← NEW file
  lib/
    useSiteContent.ts              ← NEW file
```

---

## Step 2 — Set up Firestore for dynamic content

In **Firebase Console → Firestore Database**, create this document:

**Collection:** `siteContent`  
**Document ID:** `main`

Add these fields (all optional — defaults are used if missing):

```json
{
  "branding": {
    "companyName": "Optimum Prime Solutions",
    "tagline": "Systems That Help Businesses Grow",
    "logoUrl": ""
  },
  "hero": {
    "headline": "Business Systems That Actually Work",
    "subheadline": "TallyPrime implementation, secure cloud hosting & operational consulting for growing businesses in Kenya.",
    "ctaPrimary": "Get a Free Demo",
    "ctaSecondary": "See How It Works",
    "badgeText": "🇰🇪 Trusted by Kenyan Businesses"
  },
  "contact": {
    "phone": "+254 116 246 074",
    "email": "optimumprimesolutionsltd@gmail.com",
    "address": "Ruiru, Kiambu County, Kenya",
    "whatsapp": "254116246074"
  },
  "announcement": {
    "enabled": false,
    "text": "🎉 New: Multi-branch cloud hosting now available!",
    "link": "https://optimumprimesolutions.co.ke#products"
  }
}
```

> **You can now edit any field in Firestore and the website updates in real time — no redeployment needed.**

---

## Step 3 — Update the favicon

1. Go to [favicon.io/favicon-converter](https://favicon.io/favicon-converter/)
2. Upload your `optimum_logo.jpeg`
3. Download the zip — copy `favicon.ico` and `favicon-32x32.png` into your `public/` folder
4. Update `index.html` to add:

```html
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
```

---

## Step 4 — Firestore Security Rules

In Firebase Console → Firestore → Rules, add:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Anyone can READ site content (public website)
    match /siteContent/{doc} {
      allow read: if true;
      allow write: if request.auth != null; // only logged-in admins can write
    }
  }
}
```

---

## Step 5 — Deploy

```bash
npm run build
# Deploy dist/ to Vercel / Firebase Hosting
```

---

## How to Update Content Later (no code needed)

1. Open [console.firebase.google.com](https://console.firebase.google.com)
2. Go to **Firestore Database → siteContent → main**
3. Click any field and edit it
4. Click **Update** — the site changes **instantly** for all visitors

### Example quick updates:
- Change the hero headline → edit `hero.headline`
- Show a promotional banner → set `announcement.enabled = true`, edit `announcement.text`
- Update phone number → edit `contact.phone` (updates Navbar, Footer, Contact section all at once)
- Swap logo → upload new image to Firebase Storage, copy the URL into `branding.logoUrl`

---

## Animations Added

- **Navbar**: Slides in from top on load, scroll shadow, animated mobile menu, underline hover effects
- **Hero**: Staggered word-by-word headline reveal, floating dashboard mockup card, parallax scroll, animated background blobs, floating feature cards
- **Footer**: Social icon hover effects, back-to-top button, gradient border
- **All sections**: Uses Framer Motion for smooth entrance animations

---

*Built with React 19 + TypeScript + Framer Motion + Firebase Firestore + Tailwind CSS v4*
