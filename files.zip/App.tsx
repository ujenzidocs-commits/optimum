import { BrowserRouter } from "react-router-dom";
import ErrorBoundary from "./components/ErrorBoundary";
import OfflineBanner from "./components/OfflineBanner";
import AnnouncementBanner from "./components/AnnouncementBanner";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
// Keep your existing page sections below — do NOT remove them
import Features from "./components/Features";
import Products from "./components/Products";
import HowItWorks from "./components/HowItWorks";
import Industries from "./components/Industries";
import TrustBanner from "./components/TrustBanner";
import Testimonials from "./components/Testimonials";
import About from "./components/About";
import Blog from "./components/Blog";
import FAQ from "./components/FAQ";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import WhatsAppButton from "./components/WhatsAppButton";
import Chatbot from "./components/Chatbot";
import StickyDownloadBar from "./components/StickyDownloadBar";

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        {/* Dismissable Firebase-powered banner — edit from Firestore */}
        <AnnouncementBanner />

        <Navbar />

        <main>
          <Hero />
          <TrustBanner />
          <Features />
          <Products />
          <HowItWorks />
          <Industries />
          <Testimonials />
          <About />
          <Blog />
          <FAQ />
          <Contact />
        </main>

        <Footer />
        <WhatsAppButton />
        <Chatbot />
        <StickyDownloadBar />
        <OfflineBanner />
      </BrowserRouter>
    </ErrorBoundary>
  );
}
