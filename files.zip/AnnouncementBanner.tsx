/**
 * AnnouncementBanner
 *
 * Shows a dismissable top banner driven by Firebase.
 * To activate it, set in Firestore → siteContent/main:
 *   announcement: { enabled: true, text: "...", link: "https://..." }
 */
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Megaphone } from "lucide-react";
import { useSiteContent } from "../lib/useSiteContent";

export default function AnnouncementBanner() {
  const { content } = useSiteContent();
  const [dismissed, setDismissed] = useState(false);

  const ann = content?.announcement;
  if (!ann?.enabled || dismissed) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: "auto", opacity: 1 }}
        exit={{ height: 0, opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-gradient-to-r from-blue-700 via-blue-600 to-blue-700 text-white overflow-hidden"
      >
        <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm font-medium flex-1 justify-center">
            <Megaphone size={14} className="flex-shrink-0 text-yellow-300" />
            <span>
              {ann.text}
              {ann.link && (
                <a href={ann.link} className="ml-2 underline text-yellow-300 hover:text-yellow-200 font-semibold">
                  Learn more →
                </a>
              )}
            </span>
          </div>
          <button
            onClick={() => setDismissed(true)}
            className="flex-shrink-0 hover:bg-white/20 rounded p-1 transition-colors"
            aria-label="Dismiss"
          >
            <X size={14} />
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
