/**
 * useSiteContent — Firebase-backed dynamic content hook
 *
 * Reads site-wide editable content from Firestore.
 * Falls back to hardcoded defaults if Firebase is unavailable.
 *
 * Firestore structure:
 *   /siteContent/main  → { branding, hero, contact, services, ... }
 *
 * To update content without redeploying:
 *   - Open Firebase Console → Firestore → siteContent/main
 *   - Edit any field and save — the site updates in real time.
 */

import { useEffect, useState } from "react";
import { doc, onSnapshot } from "firebase/firestore";
import { db } from "./firebase";

export interface SiteContent {
  branding: {
    logoUrl: string;        // URL to logo image (Cloudinary / Firebase Storage)
    companyName: string;
    tagline: string;
  };
  hero: {
    headline: string;
    subheadline: string;
    ctaPrimary: string;
    ctaSecondary: string;
    badgeText: string;
  };
  contact: {
    phone: string;
    email: string;
    address: string;
    whatsapp: string;
  };
  trustBanner: {
    stats: Array<{ label: string; value: string }>;
  };
  announcement?: {
    enabled: boolean;
    text: string;
    link?: string;
  };
}

const DEFAULTS: SiteContent = {
  branding: {
    logoUrl: "", // will fall back to embedded base64 in components
    companyName: "Optimum Prime Solutions",
    tagline: "Systems That Help Businesses Grow",
  },
  hero: {
    headline: "Business Systems That Actually Work",
    subheadline:
      "TallyPrime implementation, secure cloud hosting & operational consulting for growing businesses in Kenya.",
    ctaPrimary: "Get a Free Demo",
    ctaSecondary: "See How It Works",
    badgeText: "🇰🇪 Trusted by Kenyan Businesses",
  },
  contact: {
    phone: "+254 116 246 074",
    email: "optimumprimesolutionsltd@gmail.com",
    address: "Ruiru, Kiambu County, Kenya",
    whatsapp: "254116246074",
  },
  trustBanner: {
    stats: [
      { label: "Businesses Served", value: "200+" },
      { label: "Years Experience", value: "10+" },
      { label: "Uptime Guarantee", value: "99.9%" },
      { label: "Support Response", value: "<2hrs" },
    ],
  },
};

interface UseSiteContentReturn {
  content: SiteContent;
  loading: boolean;
  error: string | null;
}

export function useSiteContent(): UseSiteContentReturn {
  const [content, setContent] = useState<SiteContent>(DEFAULTS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;

    try {
      const docRef = doc(db, "siteContent", "main");

      unsubscribe = onSnapshot(
        docRef,
        (snapshot) => {
          setLoading(false);
          if (snapshot.exists()) {
            // Deep-merge Firebase data over defaults so missing fields fall back
            const firebaseData = snapshot.data() as Partial<SiteContent>;
            setContent((prev) => deepMerge(prev, firebaseData) as SiteContent);
          }
          // If doc doesn't exist yet, defaults remain — no error
        },
        (err) => {
          console.warn("useSiteContent: Firestore error, using defaults.", err);
          setError(err.message);
          setLoading(false);
        }
      );
    } catch (err) {
      console.warn("useSiteContent: Firebase init error, using defaults.", err);
      setLoading(false);
    }

    return () => unsubscribe?.();
  }, []);

  return { content, loading, error };
}

// Utility: deep-merge b into a (non-destructive, b wins on conflicts)
function deepMerge(a: unknown, b: unknown): unknown {
  if (typeof b !== "object" || b === null) return b ?? a;
  if (typeof a !== "object" || a === null) return b;
  const result = { ...(a as Record<string, unknown>) };
  for (const key of Object.keys(b as Record<string, unknown>)) {
    const bVal = (b as Record<string, unknown>)[key];
    const aVal = (a as Record<string, unknown>)[key];
    result[key] = deepMerge(aVal, bVal);
  }
  return result;
}
